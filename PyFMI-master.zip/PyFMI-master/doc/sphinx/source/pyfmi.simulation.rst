Simulation Folder
==================

Base :mod:`simulation`
-------------------------

.. automodule:: pyfmi.simulation
    :members:
    :undoc-members:
    :show-inheritance:

Module :mod:`assimulo_interface` 
--------------------------------

.. automodule:: pyfmi.simulation.assimulo_interface
    :members:
    :undoc-members:
    :show-inheritance:

