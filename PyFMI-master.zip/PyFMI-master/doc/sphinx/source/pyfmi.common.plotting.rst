Plotting Folder
================

Base :mod:`plotting`
-----------------------

.. automodule:: pyfmi.common.plotting
    :members:
    :undoc-members:
    :show-inheritance:

Module :mod:`plot_gui`
----------------------

.. automodule:: pyfmi.common.plotting.plot_gui
    :members:
    :undoc-members:
    :show-inheritance:

