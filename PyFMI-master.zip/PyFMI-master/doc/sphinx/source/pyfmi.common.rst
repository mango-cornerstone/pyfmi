Common Folder
==============

Subpackages
-----------

.. toctree::

    pyfmi.common.plotting

Base :mod:`common`
---------------------

.. automodule:: pyfmi.common
    :members:
    :undoc-members:
    :show-inheritance:

Module :mod:`algorithm_drivers` 
-------------------------------

.. automodule:: pyfmi.common.algorithm_drivers
    :members:
    :undoc-members:
    :show-inheritance:

Module :mod:`core` 
------------------

.. automodule:: pyfmi.common.core
    :members:
    :undoc-members:
    :show-inheritance:

Module :mod:`io` 
----------------

.. automodule:: pyfmi.common.io
    :members:
    :undoc-members:
    :show-inheritance:

Module :mod:`xmlparser` 
-----------------------

.. automodule:: pyfmi.common.xmlparser
    :members:
    :undoc-members:
    :show-inheritance:



